from __future__ import absolute_import, print_function, unicode_literals
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.config import config, ConfigSubsection, ConfigText, ConfigSelection
from Screens.MessageBox import MessageBox
import subprocess
import re
import os
from enigma import gRGB, eTimer
from twisted.web.client import getPage

# CONFIGURATION
config.plugins.SERVER_EAGLE_SAT = ConfigSubsection()
config.plugins.SERVER_EAGLE_SAT.username = ConfigText(default="", fixed_size=False)
config.plugins.SERVER_EAGLE_SAT.password = ConfigText(default="", fixed_size=False)
config.plugins.SERVER_EAGLE_SAT.protocol = ConfigSelection(default="cccam", choices=[("cccam", "CCCam"), ("newcamd", "Newcamd")])
config.plugins.SERVER_EAGLE_SAT.destination = ConfigSelection(default="oscam", choices=[("oscam", "OSCam"), ("ncam", "NCam")])

OSCAM_PATH = "/etc/tuxbox/config/oscam.server"
NCAM_PATH = "/etc/tuxbox/config/ncam.server"
INSTALLER_PATH = "/tmp/installer.sh"

CC_HOST = "tv8k.cc"
CC_PORT = "13000"
NC_HOST = "tv8k.cc"
NC_PORT = "14000"
NC_DESKEY = "0102030405060708091011121314"

CURRENT_VERSION = "1.1"
VERSION_URL = "https://raw.githubusercontent.com/omarsat7788/SERVER_EAGLE_SAT/main/version.txt"
INSTALLER_URL = "https://raw.githubusercontent.com/omarsat7788/SERVER_EAGLE_SAT/main/installer.sh"


# MAIN CLASS
class ServerEagleSat(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session

        # Load external skin.xml
        skin_path = os.path.join(os.path.dirname(__file__), "assets", "skin.xml")
        if not os.path.exists(skin_path):
            session.open(MessageBox, "ERROR: skin.xml missing!", MessageBox.TYPE_ERROR)
            return
        with open(skin_path, "r") as f:
            self.skin = f.read()

        # TEMP FIELDS
        self.temp_username = config.plugins.SERVER_EAGLE_SAT.username.value or ""
        self.temp_password = config.plugins.SERVER_EAGLE_SAT.password.value or ""

        # BUTTON LABELS
        self["key_red"] = Label("Delete Last")
        self["key_green"] = Label("Save and send")
        self["key_yellow"] = Label("Restart Emu")
        self["key_blue"] = Label("Clear Line")
        self["status_label"] = Label("")

        # TITLE
        self["title_info_label"] = Label("ServerEagleSat (Developed by OMARSAT)\nContact: +201011058982")

        # LABELS
        self["username_label"] = Label("Username:")
        self["password_label"] = Label("Password:")
        self["protocol_label"] = Label("Protocol:")
        self["destination_label"] = Label("Destination:")

        # VALUES
        self["username_value"] = Label(self.temp_username)
        self["password_value"] = Label(self.temp_password)
        self["protocol_value"] = Label(config.plugins.SERVER_EAGLE_SAT.protocol.value)
        self["destination_value"] = Label(config.plugins.SERVER_EAGLE_SAT.destination.value)

        # VERSION
        self["version_label"] = Label("Current Version: %s" % CURRENT_VERSION)
        self["update_status_label"] = Label("")
        self["update_button_label"] = Label("Check for Updates")

        # ACTIONS
        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "DirectionActions", "MenuActions", "NumberActions", "EPGAction"],
            {
                "ok": self.keyOk,
                "cancel": self.close,
                "green": self.saveConfig,
                "red": self.keyRed,
                "yellow": self.restartSoftcam,
                "blue": self.clearSelectedField,
                "up": self.keyUp,
                "down": self.keyDown,
                "left": self.keyLeft,
                "right": self.keyRight,
                "0": lambda: self.keyNumber("0"),
                "1": lambda: self.keyNumber("1"),
                "2": lambda: self.keyNumber("2"),
                "3": lambda: self.keyNumber("3"),
                "4": lambda: self.keyNumber("4"),
                "5": lambda: self.keyNumber("5"),
                "6": lambda: self.keyNumber("6"),
                "7": lambda: self.keyNumber("7"),
                "8": lambda: self.keyNumber("8"),
                "9": lambda: self.keyNumber("9"),
                "epg": self.keyBackspace,
            },
            -1
        )

        # FOCUS
        self.config_items = ["username", "password", "protocol", "destination", "update_button"]
        self.current_focus_index = 0
        self.onLayoutFinish.append(self.updateFocus)

        # FLICKER TIMER
        self.flickerTimer = eTimer()
        self.flickerTimer.callback.append(self.flickerEffect)
        self.flicker_on = False

    # =========================
    # FOCUS + FLICKER
    # =========================
    def updateFocus(self):
        gold = gRGB(0xFFD700)
        orange = gRGB(0xFFA500)

        for item in self.config_items:
            if item == "update_button":
                w = self["update_button_label"]
                if w.instance: w.instance.setForegroundColor(gold)
            else:
                lbl = self[f"{item}_label"]
                val = self[f"{item}_value"]
                if lbl.instance: lbl.instance.setForegroundColor(gold)
                if val.instance: val.instance.setForegroundColor(gold)

        current = self.config_items[self.current_focus_index]

        if current == "update_button":
            w = self["update_button_label"]
            if w.instance: w.instance.setForegroundColor(orange)
        else:
            lbl = self[f"{current}_label"]
            val = self[f"{current}_value"]
            if lbl.instance: lbl.instance.setForegroundColor(orange)
            if val.instance: val.instance.setForegroundColor(orange)

        self.flickerTimer.start(500, True)

    def flickerEffect(self):
        gold = gRGB(0xFFD700)
        orange = gRGB(0xFFA500)
        self.flicker_on = not self.flicker_on
        current = self.config_items[self.current_focus_index]
        color = gold if self.flicker_on else orange

        if current == "update_button":
            w = self["update_button_label"]
            if w.instance: w.instance.setForegroundColor(color)
        else:
            lbl = self[f"{current}_label"]
            val = self[f"{current}_value"]
            if lbl.instance: lbl.instance.setForegroundColor(color)
            if val.instance: val.instance.setForegroundColor(color)

        self.flickerTimer.start(500, True)

    # =========================
    # NAVIGATION
    # =========================
    def keyUp(self):
        if self.current_focus_index > 0:
            self.current_focus_index -= 1
            self.updateFocus()

    def keyDown(self):
        if self.current_focus_index < len(self.config_items) - 1:
            self.current_focus_index += 1
            self.updateFocus()

    def keyLeft(self):
        item = self.config_items[self.current_focus_index]
        if item == "protocol":
            config.plugins.SERVER_EAGLE_SAT.protocol.handleKey(0, 5)
            self["protocol_value"].setText(config.plugins.SERVER_EAGLE_SAT.protocol.value)
        elif item == "destination":
            config.plugins.SERVER_EAGLE_SAT.destination.handleKey(0, 5)
            self["destination_value"].setText(config.plugins.SERVER_EAGLE_SAT.destination.value)

    def keyRight(self):
        item = self.config_items[self.current_focus_index]
        if item == "protocol":
            config.plugins.SERVER_EAGLE_SAT.protocol.handleKey(0, 6)
            self["protocol_value"].setText(config.plugins.SERVER_EAGLE_SAT.protocol.value)
        elif item == "destination":
            config.plugins.SERVER_EAGLE_SAT.destination.handleKey(0, 6)
            self["destination_value"].setText(config.plugins.SERVER_EAGLE_SAT.destination.value)

    # =========================
    # NUMBER INPUT
    # =========================
    def keyNumber(self, n):
        item = self.config_items[self.current_focus_index]
        if item == "username":
            self.temp_username += n
            self["username_value"].setText(self.temp_username)
        elif item == "password":
            self.temp_password += n
            self["password_value"].setText(self.temp_password)

    # =========================
    # BACKSPACE (RED)
    # =========================
    def keyRed(self):
        self.keyBackspace()

    def keyBackspace(self):
        item = self.config_items[self.current_focus_index]

        if item == "username":
            if self.temp_username:
                self.temp_username = self.temp_username[:-1]
                self["username_value"].setText(self.temp_username)

        elif item == "password":
            if self.temp_password:
                self.temp_password = self.temp_password[:-1]
                self["password_value"].setText(self.temp_password)

    # =========================
    # OK → KEYBOARD
    # =========================
    def keyOk(self):
        item = self.config_items[self.current_focus_index]

        if item in ["protocol", "destination"]:
            self.keyRight()

        elif item == "update_button":
            self.checkForUpdates()

        elif item in ["username", "password"]:
            initial_text = self.temp_username if item == "username" else self.temp_password

            self.session.openWithCallback(
                lambda text, field=item: self.keyboardCallback(text, field),
                VirtualKeyBoard,
                title=f"Enter {item.capitalize()}",
                text=initial_text
            )

    def keyboardCallback(self, text, field):
        # IMPORTANT FIX: No crash when EXIT = text is None
        if text is None:
            return

        if field == "username":
            self.temp_username = text
            self["username_value"].setText(text)

        elif field == "password":
            self.temp_password = text
            self["password_value"].setText(text)

    # =========================
    # SAVE CONFIG
    # =========================
    def saveConfig(self):
        config.plugins.SERVER_EAGLE_SAT.username.value = self.temp_username
        config.plugins.SERVER_EAGLE_SAT.password.value = self.temp_password

        for item in self.config_items:
            if item != "update_button" and hasattr(config.plugins.SERVER_EAGLE_SAT, item):
                getattr(config.plugins.SERVER_EAGLE_SAT, item).save()

        username = self.temp_username
        password = self.temp_password
        protocol = config.plugins.SERVER_EAGLE_SAT.protocol.value
        dest = config.plugins.SERVER_EAGLE_SAT.destination.value

        file_path = OSCAM_PATH if dest == "oscam" else NCAM_PATH

        if not username or not password:
            self.session.open(MessageBox, "Username and Password cannot be empty!", MessageBox.TYPE_INFO)
            return

        reader = (
            self.generate_cccam_reader(username, password, 1, 1)
            if protocol == "cccam"
            else self.generate_newcamd_reader(username, password, 1, 1)
        )

        self.add_or_replace_reader(file_path, reader, protocol)

        self.session.open(
            MessageBox,
            "Configuration saved!\nReader replaced or added.\nRestart softcam to apply.",
            MessageBox.TYPE_INFO,
            timeout=4
        )

    # =========================
    # CLEAR FIELD
    # =========================
    def clearSelectedField(self):
        item = self.config_items[self.current_focus_index]

        if item == "username":
            self.temp_username = ""
            self["username_value"].setText("")
            msg = "Username cleared."

        elif item == "password":
            self.temp_password = ""
            self["password_value"].setText("")
            msg = "Password cleared."

        else:
            msg = "Cannot clear this field."

        self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=3)

    # =========================
    # RESTART SOFTCAM
    # =========================
    def restartSoftcam(self):
        cmd = "/etc/init.d/softcam restart"
        try:
            subprocess.run(cmd, shell=True, check=True)
            self.session.open(MessageBox, "Softcam restarted!", MessageBox.TYPE_INFO, timeout=3)
        except:
            self.session.open(MessageBox, "Softcam restart failed!", MessageBox.TYPE_ERROR)

    # =========================
    # CLOSE SCREEN
    # =========================
    def close(self):
        self.flickerTimer.stop()
        if (
            self.temp_username != config.plugins.SERVER_EAGLE_SAT.username.value
            or self.temp_password != config.plugins.SERVER_EAGLE_SAT.password.value
        ):
            self.session.openWithCallback(
                self.exit_confirm,
                MessageBox,
                "Changes not saved. Exit anyway?",
                MessageBox.TYPE_YESNO
            )
        else:
            Screen.close(self)

    def exit_confirm(self, res):
        if res:
            Screen.close(self)

    # =========================
    # UPDATE SYSTEM
    # =========================
    def checkForUpdates(self):
        self["update_status_label"].setText("Checking for updates...")
        d = getPage(VERSION_URL.encode("utf-8"))
        d.addCallback(self.updateCheckCallback).addErrback(self.updateCheckError)

    def updateCheckCallback(self, data):
        latest = data.decode("utf-8").strip()
        if latest > CURRENT_VERSION:
            msg = f"New version {latest} available. Update now?"
            self.session.openWithCallback(
                self.update_confirmation_callback,
                MessageBox,
                msg,
                MessageBox.TYPE_YESNO
            )
        else:
            self["update_status_label"].setText("No updates available.")

    def update_confirmation_callback(self, res):
        if res:
            self.performUpdate()
        else:
            self["update_status_label"].setText("Update canceled.")

    def updateCheckError(self, error):
        self["update_status_label"].setText("Failed to check update.")

    def performUpdate(self):
        self["update_status_label"].setText("Downloading update...")
        d = getPage(INSTALLER_URL.encode("utf-8"))
        d.addCallback(self.downloadInstallerCallback).addErrback(self.downloadInstallerError)

    def downloadInstallerCallback(self, data):
        try:
            with open(INSTALLER_PATH, "wb") as f:
                f.write(data)
            os.chmod(INSTALLER_PATH, 0o755)
            self.executeInstaller()
        except:
            self.session.open(MessageBox, "Installer save error!", MessageBox.TYPE_ERROR)

    def downloadInstallerError(self, error):
        self.session.open(MessageBox, "Download failed!", MessageBox.TYPE_ERROR)

    def executeInstaller(self):
        self["update_status_label"].setText("Installing...")
        try:
            subprocess.run([INSTALLER_PATH], check=True)
            self.session.open(MessageBox, "Update successful! Reboot required.", MessageBox.TYPE_INFO)
        except:
            self.session.open(MessageBox, "Update failed!", MessageBox.TYPE_ERROR)

    # =========================
    # READER GENERATORS
    # =========================
    def add_or_replace_reader(self, file_path, new_reader, protocol):
        prefix = "SERVER EAGLE SAT_C" if protocol == "cccam" else "SERVER EAGLE SAT_N"
        regex = r'(\[reader\].*?label\s*=\s*' + re.escape(prefix) + r'1.*?)(?=\[reader\]|\Z)'

        try:
            with open(file_path, "r") as f:
                content = f.read()
        except FileNotFoundError:
            content = ""

        if re.search(regex, content, re.DOTALL | re.IGNORECASE):
            content = re.sub(regex, new_reader, content, flags=re.DOTALL | re.IGNORECASE)
        else:
            if content and not content.endswith("\n"):
                content += "\n"
            content += new_reader

        with open(file_path, "w") as f:
            f.write(content)

    def generate_cccam_reader(self, user, pwd, num, group):
        return f"""[reader]
label = SERVER EAGLE SAT C{num}
enable = 1
protocol = cccam
device = {CC_HOST},{CC_PORT}
user = {user}
password = {pwd}
inactivitytimeout = 30
group = {group}
cccversion = 2.3.2
disablecrccws = 1
cccmaxhop = 1
cccwantemu = 1
ccckeepalive = 1
audisabled = 1
lb_whitelist_services = 1814
"""

    def generate_newcamd_reader(self, user, pwd, num, group):
        return f"""[reader]
label = SERVER EAGLE SAT N{num}
enable = 1
protocol = newcamd
device = {NC_HOST},{NC_PORT}
user = {user}
password = {pwd}
key = {NC_DESKEY}
inactivitytimeout = 0
disablecrccws = 1
disableserverfilter = 1
connectoninit = 1
group = {group}
"""

